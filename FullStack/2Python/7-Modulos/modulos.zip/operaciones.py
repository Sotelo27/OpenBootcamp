def suma(numero,numero2):
    return numero + numero2

def resta(numero,numero2):
    return numero - numero2

def multiplicar(numero,numero2):
    return numero * numero2

def dividir(numero,numero2):
    return numero / numero2

