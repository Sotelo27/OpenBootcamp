'''
Desde la consola de python almacena la cadena “Hola mundo!” en una variable y muéstrala.

Tienes que subir capturas de pantalla en una carpeta comprimida zip.
'''

def main():
    cadena = "Hola mundo!"
    print(cadena)

main()