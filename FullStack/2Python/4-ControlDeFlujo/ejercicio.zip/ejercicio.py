#Escribe un programa que sea capaz de 
#mostrar los números del 1 al 100 en orden inverso.

def main():
    for numeros in range (100):
        print(100-numeros)

main()